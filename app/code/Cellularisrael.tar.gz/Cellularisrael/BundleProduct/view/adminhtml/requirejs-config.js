var config = {
    "map": {
        "*": {
            'mage/backend/suggest': 'Cellularisrael_BundleProduct/js/mage/backend/suggest',
            'suggest': 'Cellularisrael_BundleProduct/js/mage/backend/suggest',
            'Magento_Ui/js/dynamic-rows/dnd': 'Cellularisrael_BundleProduct/js/dynamic-rows/dnd'
        }
    }
};