var config = {
    config: {
        mixins: {
            'Magento_Search/js/form-mini': {
                'Mirasvit_SearchAutocomplete/js/form-mini': true
            },
        },
    },
};
