/*eslint-disable */
define([], function () {
  return {};
});
//# sourceMappingURL=types.js.map