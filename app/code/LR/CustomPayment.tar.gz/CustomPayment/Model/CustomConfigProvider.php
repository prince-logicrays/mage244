<?php

namespace LR\CustomPayment\Model;

use Magento\Checkout\Model\ConfigProviderInterface;
use Magento\SamplePaymentGateway\Gateway\Http\Client\ClientMock;
use Magento\Framework\App\Config\ScopeConfigInterface;

class CustomConfigProvider implements ConfigProviderInterface
{
    public const CUSTOM_PAYMENT_TITLE = 'payment/custompayment/custom_payment_title';

    /**
     * @var ScopeConfigInterface
     */
    protected $scopeConfig;

    /**
     * Undocumented function
     *
     * @param ScopeConfigInterface $scopeConfig
     */
    public function __construct(
        ScopeConfigInterface $scopeConfig,
    ) {
        $this->scopeConfig = $scopeConfig;
    }

    /**
     * Undocumented function
     *
     * @return void
     */
    public function getConfig()
    {
        $config = [];
        $config['payment']['customTitle'] = $this->getCustomPaymentTitle();
        return $config;
    }

    /**
     * Get custom payment title
     *
     * @return int
     */
    public function getCustomPaymentTitle()
    {
        $storeScope = \Magento\Store\Model\ScopeInterface::SCOPE_STORE;
        return $this->scopeConfig->getValue(self::CUSTOM_PAYMENT_TITLE, $storeScope);
    }
}
