define(
    [
        'Magento_Checkout/js/view/payment/default'
    ],
    function (Component) {
        'use strict';
  
        return Component.extend({
            defaults: {
                template: 'LR_CustomPayment/payment/custompayment'
            },
            /**
             * Display Custom Title
             */
            displayCustomTitle: function () {
                return window.checkoutConfig.payment.customTitle;
            }
        });
    }
);