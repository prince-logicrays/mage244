/**
 * Copyright © 2018 Cardknox Development Inc. All rights reserved.
 * See LICENSE for license details.
 */
 var config = {
    paths: {
        ifields: 'https://cdn.cardknox.com/ifields/2.15.2302.0801/ifields.min'
    }
};