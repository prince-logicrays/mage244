<?php


\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'CardknoxDevelopment_Cardknox',
    __DIR__
);
