<?php
namespace Logicrays\ManageCategoryImage\Controller\Adminhtml\ManageCategoryImage;

use Magento\Framework\App\Action\HttpPostActionInterface;
use Magento\Backend\App\Action;
use Magento\Framework\App\Filesystem\DirectoryList;

class Save extends Action implements HttpPostActionInterface
{
    /**
     * @var \Magento\Framework\View\Result\PageFactory
     */
    protected $_pageFactory;

    /**
     * @var \Logicrays\ManageCategoryImage\Model\ManageCategoryImageFactory
     */
    protected $manageCategoryImageFactory;

    /**
     * @var \Magento\Framework\Data\Form\FormKey\Validator
     */
    protected $formKeyValidator;

    /**
     * @var \Logicrays\ManageCategoryImage\Model\CategoryOptionImageFactory
     */
    protected $categoryOptionImageFactory;

    /**
     * @var \Magento\Framework\Serialize\Serializer\Json
     */
    protected $json;

    /**
     * @var \Magento\MediaStorage\Model\File\UploaderFactory
     */
    protected $uploaderFactory;

    /**
     * @var \Magento\Framework\Image\AdapterFactory
     */
    protected $adapterFactory;

    /**
     * @var \Magento\Framework\Filesystem
     */
    protected $filesystem;

    /**
     * __construct function
     *
     * @param \Magento\Backend\App\Action\Context $context
     * @param \Magento\Framework\View\Result\PageFactory $pageFactory
     * @param \Logicrays\ManageCategoryImage\Model\ManageCategoryImageFactory $manageCategoryImageFactory
     * @param \Magento\Framework\Data\Form\FormKey\Validator $formKeyValidator
     * @param \Logicrays\ManageCategoryImage\Model\CategoryOptionImageFactory $categoryOptionImageFactory
     * @param \Magento\Framework\Serialize\Serializer\Json $json
     * @param \Magento\MediaStorage\Model\File\UploaderFactory $uploaderFactory
     * @param \Magento\Framework\Image\AdapterFactory $adapterFactory
     * @param \Magento\Framework\Filesystem $filesystem
     */
    public function __construct(
        \Magento\Backend\App\Action\Context $context,
        \Magento\Framework\View\Result\PageFactory $pageFactory,
        \Logicrays\ManageCategoryImage\Model\ManageCategoryImageFactory $manageCategoryImageFactory,
        \Magento\Framework\Data\Form\FormKey\Validator $formKeyValidator,
        \Logicrays\ManageCategoryImage\Model\CategoryOptionImageFactory $categoryOptionImageFactory,
        \Magento\Framework\Serialize\Serializer\Json $json,
        \Magento\MediaStorage\Model\File\UploaderFactory $uploaderFactory,
        \Magento\Framework\Image\AdapterFactory $adapterFactory,
        \Magento\Framework\Filesystem $filesystem
    ) {
        $this->_pageFactory = $pageFactory;
        $this->manageCategoryImageFactory = $manageCategoryImageFactory;
        $this->formKeyValidator = $formKeyValidator;
        $this->categoryOptionImageFactory = $categoryOptionImageFactory;
        $this->json = $json;
        $this->uploaderFactory = $uploaderFactory;
        $this->adapterFactory = $adapterFactory;
        $this->filesystem = $filesystem;
        return parent::__construct($context);
    }

    /**
     * Index action
     *
     * @return \Magento\Framework\View\Result\Page
     */
    public function execute()
    {
        $resultPageFactory = $this->resultRedirectFactory->create();
        if (!$this->formKeyValidator->validate($this->getRequest())) {
            $this->messageManager->addErrorMessage(__("Form key is Invalidate"));
            return $resultPageFactory->setPath('*/*/index');
        }
        $data = $this->getRequest()->getParams();

        // echo '<pre>';
        // print_r($data);
        // die;

        $atributes = implode(',', $data['attributes']);
        $saveData = [
            'category_id' => $data['category_id'],
            'attributes' => $atributes,
        ];

        $msg = 'Saved';
        // make condition for updates
        if (array_key_exists("id", $data)) {
            // $this->setReferenceTableData();

            $saveData = [
                'category_id' => $data['category_id'],
                'attributes' => $atributes,
                'id' => $data['id']
            ];
            $msg = 'Updated';
        }

        try {
            if ($saveData) {
                $model = $this->manageCategoryImageFactory->create();
                $model->setData($saveData)->save();
                $id = $model->getId();
            }
            $this->messageManager->addSuccessMessage(__("Category Image $msg Successfully."));
            return $resultPageFactory->setPath('*/*/edit', ['id' => $id]);
        } catch (\Exception $e) {
            $this->messageManager->addErrorMessage($e, __("We can't submit your request, Please try again."));
        }
    }

    /**
     * Set Reference TableData function
     *
     * @return array
     */
    public function setReferenceTableData()
    {
        $data = $this->getRequest()->getParams();
        echo '<pre>';
        print_r($data);
        $imageFile = $this->getRequest()->getFiles();
        print_r($imageFile);
        die;

        $attributeOptions = [];
        foreach ($data as $key => $value) {
            if (strpos($key, 'attributeoption_') === 0) {
                $keys = explode('_', $key);
                $attributeOptions[$keys[2].'_'.$keys[3]] = $value;
                if ($keys[3] == 'image') {
                    $imageToSave = $this->setImageUpload($key);
                }
            }
        }

        $separatedRowValues = [];
        foreach ($attributeOptions as $key => $value) {
            $index = explode('_', $key);
            if (isset($separatedRowValues[$index[0]])) {
                $separatedRowValues[$index[0]][$index[1]] = $value;
            } else {
                $separatedRowValues[$index[0]] = [$index[1] => $value];
            }
        }
// echo '<pre>';
// print_r($separatedRowValues);
// die;
        try {
            foreach ($separatedRowValues as $separatedRow) {
                $image = $separatedRow['image'];
                unset($separatedRow['image']);

                $jsonAttributeOptions = $this->json->serialize($separatedRow);

                $saveReferenceTableData = [
                    'category_id' => $data['category_id'],
                    'attribute_options' => $jsonAttributeOptions,
                    'image' => $image
                ];

                // if ($saveReferenceTableData) {
                //     $model = $this->categoryOptionImageFactory->create();
                //     $model->setData($saveReferenceTableData)->save();
                // }
            }
        } catch (\Exception $e) {
            $this->messageManager->addErrorMessage($e, __("We can't submit your request, Please try again."));
        }
    }

    /**
     * SetImageUpload function
     *
     * @param string $imageRowFieldId
     * @return array
     */
    public function setImageUpload($imageRowFieldId)
    {
        $imageFile = $this->getRequest()->getFiles();
        echo '<pre>';
        print_r($imageFile);

        // foreach ($imageFile as $key => $image) {
        //     print_r($key);
        //     print_r($image);
        // }
        die;

        try {
            $uploaderFactory = $this->uploaderFactory->create(['fileId' => $imageRowFieldId]);
            $uploaderFactory->setAllowedExtensions(['jpg', 'jpeg', 'gif', 'png']);
            // $fileAdapter = $this->adapterFactory->create();
            $uploaderFactory->setAllowRenameFiles(true);
            $uploaderFactory->setFilesDispersion(true);
            $mediaDirectory = $this->filesystem->getDirectoryRead(DirectoryList::MEDIA);
            $destinationPath = $mediaDirectory->getAbsolutePath('LrCategoryImage/');
            $result = $uploaderFactory->save($destinationPath);

            if (!$result) {
                throw new LocalizedException (
                    __('File cannot be saved to path: $1', $destinationPath)
                );
            }
            return $result['file'];

        } catch (\Exception $e) {
            $this->messageManager->addError(__("Image not Upload Pleae Try Again"));
        }
    }

    /**
     * Is the user allowed to view the page.
     *
     * @return bool
     */
    protected function _isAllowed()
    {
        return $this->_authorization->isAllowed('Logicrays_ManageCategoryImage::managecategoryimage_save');
    }
}
